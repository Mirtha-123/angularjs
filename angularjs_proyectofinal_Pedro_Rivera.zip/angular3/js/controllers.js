'use strict';



var motorAppControllers = angular.module('motorAppControllers', []);


motorAppControllers.controller('motorListCtrl', ['$scope', 'Moto',
  function($scope, Moto) {
    $scope.motor = Moto.query();
    $scope.orderProp = 'model';
  }]);

motorAppControllers.controller('motorDetailCtrl', ['$scope', '$routeParams', 'Moto',
  function($scope, $routeParams, Moto) {
    $scope.motor = Moto.get({motoId: $routeParams.motoId}, function(moto) {
      $scope.mainImageUrl = moto.images[0];
    });

    $scope.setImage = function(imageUrl) {
      $scope.mainImageUrl = imageUrl;
    }
  }]);