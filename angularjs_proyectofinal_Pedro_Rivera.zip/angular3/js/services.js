'use strict';

var motorAppServices = angular.module('motorAppServices', ['ngResource']); 
motorAppServices.factory('Moto', ['$resource',
  function($resource){
    return $resource('motor/:motoId.json', {}, {
      query: {method:'GET', params:{motoId:'motor'}, isArray:true}
    });
  }]);
