'use strict';


var motoApp = angular.module('motoApp', [
	'ngRoute',
  'carAppAnimations',
  'motorAppControllers',
  'motorAppServices' 
]);


motoApp.config(['$routeProvider',
  function($routeProvider) {
    $routeProvider.
      when('/motors', {
        templateUrl: 'partials/motor-list.html',
        controller: 'motorListCtrl'
      }).
      when('/motors/:motoId', {
        templateUrl: 'partials/motor-detail.html',
        controller: 'motorDetailCtrl'
      }).
      otherwise({
        redirectTo: '/motors'
      });
  }]);